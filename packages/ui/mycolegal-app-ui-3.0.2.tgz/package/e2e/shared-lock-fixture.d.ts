/**
 * Playwright extensions for the shared-lock dedup system.
 *
 * Apps wire it like this in their Playwright `test.beforeEach` or via a
 * fixture extension, and add `SharedLockReporter` to their `reporter` array
 * in `playwright.config.ts`.
 *
 * See `./shared-lock.ts` for the why/how.
 */
import type { Reporter, TestCase, TestResult } from '@playwright/test/reporter';
/**
 * Skips a test when any of its `@shared:*` tags has already been recorded
 * as passed in the current run's lockfile. Apps can either call this from
 * a manual `test.beforeEach` or use the `test` re-export below.
 */
export declare function skipIfSharedAlreadyPassed(testInfo: {
    tags: readonly string[];
    skip: (reason?: string) => void;
}): Promise<void>;
/**
 * Drop-in replacement for the default `test` import that auto-applies the
 * shared-lock skip logic. Apps that want zero boilerplate can import this
 * instead of `@playwright/test`'s `test`.
 *
 * Everything else from `@playwright/test` is re-exported so specs can keep
 * a single import line (request, devices, types, etc.). The local `test`
 * binding below shadows the re-exported one — order matters.
 */
export * from '@playwright/test';
export declare const test: import("playwright/test").TestType<import("playwright/test").PlaywrightTestArgs & import("playwright/test").PlaywrightTestOptions & {
    _sharedLockGuard: void;
}, import("playwright/test").PlaywrightWorkerArgs & import("playwright/test").PlaywrightWorkerOptions>;
/**
 * Playwright reporter that writes successful `@shared:*` tags to the
 * lockfile. Add to `playwright.config.ts`:
 *
 *   reporter: [
 *     ['list'],
 *     ['@mycolegal-app/ui/e2e/shared-lock-fixture', { appSlug: 'notaria' }],
 *   ],
 */
export default class SharedLockReporter implements Reporter {
    private appSlug?;
    constructor(options?: {
        appSlug?: string;
    });
    onTestEnd(test: TestCase, result: TestResult): void;
}
